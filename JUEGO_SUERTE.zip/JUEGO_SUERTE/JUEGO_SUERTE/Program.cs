﻿using System;

namespace JUEGO_SUERTE
{
    public class Juego
    {
        public int Numero_azar;

        public void Jugar()
        {
            Random azar = new Random();
            Numero_azar = azar.Next(1, 100);
        }

        public void condiciones()
        {
            Juego j = new Juego();
            j.Jugar();
            int x = 1, Intento;
            int valor = 0;
            do
            {
                Console.WriteLine("Ingrese su numero:");
                Intento = int.Parse(Console.ReadLine());
                int operacion = Intento - j.Numero_azar;
                if (-5 <= operacion && operacion <= 5)
                {
                    Console.WriteLine("Estas muy caliente");
                }
                else if (-10 <= operacion && operacion <= 10)
                {
                    Console.WriteLine("Estas caliente");

                }
                else if (-20 <= operacion && operacion <= 20)
                {
                    Console.WriteLine("Estas tibio");
                }
                else if (-30 <= operacion && operacion <= 30)
                {
                    Console.WriteLine("Estas frio");
                }
                else if (-50 <= operacion && operacion <= 50)
                {
                    Console.WriteLine("Estas muy frio");
                }

                if (Intento == j.Numero_azar)
                {
                    Console.WriteLine("\nGanaste");
                    Console.WriteLine("Ganaste\nEl numero era {0}",j.Numero_azar);
                }
                if(x >= 10)
                {
                    Console.WriteLine("\nPerdiste");
                    Console.WriteLine("Perdiste\nEl numero era {0}",j.Numero_azar);
                }
                x++;
            } while (Intento != j.Numero_azar && x <= 10);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Juego jugar = new Juego();
            int opcion = 0;
            while(opcion != 2)
            {
                Console.WriteLine("--Menu del Juego--\n1- Jugar\n2- Salir");
                opcion = int.Parse(Console.ReadLine());
                Console.Clear();
                switch (opcion)
                {
                    case 1:
                        jugar.condiciones();
                        break;
                    case 2:
                        Console.Clear();
                        Console.WriteLine("Fin del Juego");
                        break;
                }
            }
        }
    }
}
