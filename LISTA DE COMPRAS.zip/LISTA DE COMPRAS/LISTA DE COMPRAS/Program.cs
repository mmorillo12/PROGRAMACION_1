﻿using System;

namespace LISTA_DE_COMPRAS
{
    public class listas
    {
        string[] frutas = new string[10];
        string[] vegetales = new string[10];
        string[] lacteos = new string[10];
        int numerodeproducto;
        //Propiedade Agregar
        public void Agregar()
        {

        }
        //Propiedades de mostrar
        public void Listar_Frutas()
        {
            foreach(string x in frutas)
            {
                Console.WriteLine(x);
            }
        }
        public void Listar_Vegetales()
        {
            foreach (string x in vegetales)
            {
                Console.WriteLine(x);
            }
        }
        public void Listar_Lacteos()
        {
            foreach (string x in lacteos)
            {
                Console.WriteLine(x);
            }
        }
        public void Listar_Todos()
        {
            foreach (string x in frutas)
            {
                Console.WriteLine(x);
            }
            foreach (string j in lacteos)
            {
                Console.WriteLine(j);

                foreach (string a in vegetales)
                {
                    Console.WriteLine(a);
                }
            }
        }
        //Propiedad de Editar de Lista en especifica
        public void Editar_Lista()
        {

        }
        //Propiedad Borrar elementos dentro de una lista en especifica
        public void Borrar_Lista()
        {

        }
    }   

    public class Ejecutable
    {
        public void Mostrar_Todo()
        {
            listas ls = new listas();
            int opcion = 0;
            while (opcion != 4)
            {
                Console.WriteLine("--Menu de Compras--\n1- Agregar\n2- Ver Lista completa\n3- Ver solo Frutas\n4- Ver solo Vegetales\n5- Ver solo Lacteos\n6- Editar Lista de compras\n7- Borrar Elemento de Lista\n8-Salir");
                opcion = int.Parse(Console.ReadLine());
                Console.Clear();
                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("Agregue elementos a su lista");
                        ls.Agregar();
                        break;
                    case 2:
                        Console.WriteLine("Lista Completa");
                        break;
                    case 3:
                        Console.WriteLine("Lista de Frutas");
                        ls.Listar_Frutas();
                        break;
                    case 4:
                        Console.WriteLine("Lista de Vegetales");
                        ls.Listar_Vegetales();
                        break;
                    case 5:
                        Console.WriteLine("listas de Lacteos");
                        ls.Listar_Lacteos();
                        break;
                    case 6:
                        Console.WriteLine("Editar Lista");
                        ls.Editar_Lista();
                        break;
                    case 7:
                        Console.WriteLine("Borrar elemento de lista");
                        ls.Borrar_Lista();
                        break;
                    case 8:
                        Console.Clear();
                        Console.WriteLine("Fin del Programa");
                        break;
                }
            }
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Ejecutable ver = new Ejecutable();
            ver.Mostrar_Todo();
        }
    }
}
