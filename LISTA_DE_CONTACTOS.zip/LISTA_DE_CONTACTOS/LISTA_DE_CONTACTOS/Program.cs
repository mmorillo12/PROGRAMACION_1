﻿using System;
using System.Linq;

namespace LISTA_DE_CONTACTOS
{
    class Program
    {
        public class Lista
        {
            string[] nombre = new string[15];
            string[] telofono = new string[15];
            int numero_lista;

            public void Agregar() //Opcion de agregado
            {
                Console.WriteLine("Escoga una opcion");
                int opcion = 0;
                do
                {
                    //Aqui se insertan los valores de la lista
                    Console.WriteLine("Ingrese el nombre del contacto: ");
                    nombre[numero_lista] = Console.ReadLine();
                    Console.WriteLine("Ingrese el telefono del contacto: ");
                    telofono[numero_lista] = Console.ReadLine();
                    //Opcion para salir o seguir en la primera opcion
                    Console.WriteLine("Desea salir de la opcion 'Agregar'?");
                    Console.WriteLine("- Si desea salir presione -1");
                    Console.WriteLine("- Si desea seguir agregando presione 2");
                    opcion = int.Parse(Console.ReadLine());
                    numero_lista++;
                    //Defino la condicion para que salga de la opcion si lo desea
                    if(opcion == -1)
                    {
                        break;
                    }
                    else
                    {
                        continue;
                    }
                } while ((numero_lista <= 15) && (opcion != -1));
            }
            public void Listar()
            {
                for (int i = 0; i < numero_lista; i++)
                {
                    Console.WriteLine("El contacto {0} se llama {1}", i, nombre[i]);
                    Console.WriteLine("El numero de {0} es {1}", nombre[i], telofono[i]);

                }
            }
            public void Editar()
            {
                string nuevoC, nuevoN, verificar;
                Console.WriteLine("Ingrese el nombre del contacto que desea alterar");
                verificar = Console.ReadLine();
                for (int i = 0; i < 1; i++)
                {
                    if (nombre[i] == verificar)
                    {
                        nombre[i] = verificar;
                    }
                    else
                    {
                        Console.WriteLine("Nombre no encontrado");
                    }

                    Console.WriteLine("Ingrese el nuevo nombre de su contacto");
                    nuevoC = Console.ReadLine();
                    nombre[i] = nuevoC;
                    Console.WriteLine("Ingrese el nuevo numero de contacto");
                    nuevoN = Console.ReadLine();
                    telofono[i] = nuevoN;
                }
            }
            public void Eliminar()
            {
                int borrar;
                Console.WriteLine("Ingrese el numero del contacto que desea eliminar");
                borrar = int.Parse(Console.ReadLine());
                nombre = nombre.Where((source, index) => index != borrar).ToArray();
                telofono = telofono.Where((source, index) => index != borrar).ToArray();

            }
        }
        public class Ejecutable
        {
            public void Final()
            {
                Lista lista = new Lista();
                int valor = 0;
                while (valor != 5)
                {
                    Console.WriteLine("1 - Agregar Contacto\n2 - Listar Contacto\n3 - Editar Contacto\n4 - Eliminar Contacto");
                    valor = int.Parse(Console.ReadLine());
                    Console.Clear();
                    switch (valor)
                    {
                        case 1:
                            lista.Agregar();
                            break;
                        case 2:
                            lista.Listar();
                            break;
                        case 3:
                            lista.Editar();
                            break;
                        case 4:
                            lista.Eliminar();
                            break;
                        case 5:
                            Console.Clear();
                            Console.WriteLine("Fin del programa");
                            break;
                    }
                }
            }
        }
        static void Main(string[] args)
        {
            Ejecutable ejecutable = new Ejecutable();
            ejecutable.Final();
        }
    }
}

